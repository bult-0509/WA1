"""开发机运行一次；答辩时直接读取准备好的数据。"""
from pathlib import Path
import json
from src.data_processing import prepare
from src.clustering import train

ROOT = Path(__file__).resolve().parent
if __name__ == '__main__':
    quality = prepare(ROOT / 'data/raw', ROOT / 'data/processed')
    print(json.dumps(quality, ensure_ascii=False, indent=2), flush=True)
    print(json.dumps(train(ROOT / 'data/processed'), ensure_ascii=False, indent=2), flush=True)
